function resultCallback( resultData )
{
   window.location = ( "http://" + resultData )
}

function test2On2()
{
   resultCallback( 2*2 );
}
