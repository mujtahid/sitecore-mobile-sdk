#import "SCWebViewContainer.h"

@implementation SCWebViewContainer
{
   __strong SCWebView* _webView;
   __strong NSString* _JSToTest;
}

@synthesize testWebViewRequest;

-(id)initWithJSResourcePath:( NSString* )path_
                   JSToTest:( NSString* )JSToTest_
{
   self = [ super init ];

   if ( self )
   {
      _webView = [ SCWebView new ];
      [ _webView.ownerships addObject: self ];
      _webView.delegate = self;

      [ _webView loadHTMLString: @"" baseURL: nil ];

      _JSToTest = JSToTest_;

      NSString* javascript_ = [ NSString stringWithContentsOfFile: path_
                                                         encoding: NSUTF8StringEncoding
                                                            error: nil ];

      [ _webView stringByEvaluatingJavaScriptFromString: javascript_ ];
   }

   return self;
}

#pragma mark SCWebViewDelegate

-(void)webViewDidFinishLoad:(SCWebView *)webView
{
   [ _webView stringByEvaluatingJavaScriptFromString: _JSToTest ];
}

- (BOOL)webView:(SCWebView *)webView
shouldStartLoadWithRequest:(NSURLRequest *)request_
 navigationType:(UIWebViewNavigationType)navigationType
{
   if ( [ [ request_.URL absoluteString ] isEqualToString: @"about:blank" ] )
      return YES;

   if ( testWebViewRequest( request_ ) )
      [ _webView.ownerships removeObject: self ];

   return NO;
}

@end

