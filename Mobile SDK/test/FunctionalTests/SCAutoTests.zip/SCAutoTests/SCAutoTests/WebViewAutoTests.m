#import "SCAsyncTestCase.h"

#import "SCWebViewContainer.h"

@interface WebViewAccountsTest : SCAsyncTestCase
@end

@implementation WebViewAccountsTest

-(void)testCreateAccount
{
   __block BOOL authed_ = NO;

   void (^block_)(JFFSimpleBlock) = ^void( JFFSimpleBlock did_finish_callback_ )
   {
      NSString* path_ = [ [ NSBundle mainBundle ] pathForResource: @"tests"
                                                           ofType: @"js" ];
      SCWebViewContainer* container_ =
         [ [ SCWebViewContainer alloc ] initWithJSResourcePath: path_
                                                      JSToTest: @"test2On2()" ];

      did_finish_callback_ = [ did_finish_callback_ copy ];
      container_.testWebViewRequest = ^BOOL( NSURLRequest* request_ )
      {
         if ( [ request_.URL.host isEqualToString: @"4" ] )
            authed_ = YES;

         did_finish_callback_();

         return YES;
      };
   };

   [ self performAsyncRequestOnMainThreadWithBlock: block_
                                          selector: _cmd ];

   GHAssertTrue( authed_, @"Session should be authorized here" );
}

@end
