﻿// --------------------------------------------------------------------------------------------------------------------- 
// <copyright file="Product.ascx.cs" company="Sitecore">
//   Copyright (C) 1999-2009 by Sitecore A/S. All rights reserved.
// </copyright>
// <summary>
//   Defines the Product type.
// </summary>
// ---------------------------------------------------------------------------------------------------------------------
namespace NiCam.layouts
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web.UI;
    using System.Web.UI.WebControls;
    using AnalyticsTrackingHelper.BusinessLayer;
    using NiCam.Analytics;
    using Sitecore.Analytics.Extensions.AnalyticsPageExtensions;
    
   public partial class Product : UserControl
   {
       /// <summary>
       /// Handles the Load event of the Page control.
       /// </summary>
       /// <param name="sender">The source of the event.</param>
       /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            if (Sitecore.Context.Item != null && Session["NicamProductTabID"] != null &&
               Sitecore.Context.Item.ID.ToString() != Session["NicamProductTabID"].ToString())
            {
               this.SaveTabToSession("Specifications");
            }

            this.TrigerEvent();
         }

         this.RenderSublayoutWithXSLT();
      }

      private void TrigerEvent()
      {
          if (Sitecore.Context.Request.QueryString["pf"] == "1")
          {
            Sitecore.Data.Items.Item item = Sitecore.Context.Item;
            AnalyticsTrackerHelper.TriggerEvent("Product finder Select product", "Product: \"" + item.Name + "\"", string.Empty, string.Empty, "PreviousPage");
            
            //// Raise lead scoring triggering

            NiCam.Modules.LeadScoring.ProductFinderScoring.TrigerSelectProduct();
          }
      }

      protected void Tab_Click(object sender, CommandEventArgs e)
      {
         this.SaveTabToSession(e.CommandArgument.ToString());
         this.RenderSublayoutWithXSLT();
      }

      private void RenderSublayoutWithXSLT()
      {
         var temp = new UserControl();

         if (Session["NicamProductTabName"] != null && (Session["NicamProductTabName"].ToString().Equals("Reviews") || Session["NicamProductTabName"].ToString().Equals("Accessories")))
         {
             TabContent.Controls.Clear();
         }
         else
         {
             TabContent.Controls.Clear();
             var ctrl = temp.LoadControl("/layouts/Nicam/ProductTabContent.ascx");
             TabContent.Controls.Add(ctrl);
         }
      }

      private void SaveTabToSession(string tabName)
      {
         if (Sitecore.Context.Item != null)
         {
            Session["NicamProductTabName"] = tabName;
            Session["NicamProductTabID"] = Sitecore.Context.Item.ID.ToString();
         }
      }
   }
}